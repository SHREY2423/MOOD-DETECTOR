# Translation (Hindi/Urdu to English)
