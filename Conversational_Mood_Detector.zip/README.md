# Conversational Mood Detector (CMD)
This app detects mood by asking multiple questions and analyzing responses.